# DeepAzure_Project
Proof of concept Hadoop Map/Reduce Mongo DB loader, adapted from a Grid Computing Mongo DB Loader

Setup Cosmos DB with Mongo DB API and copy out the connection string and update the com.relayhealth.mongoloader.MongoConnection.java with the connection string.
